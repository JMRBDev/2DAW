<?php
    //Clase abstracta para construir objetos
    abstract class AbstractBase{
        abstract function obtenerTodos();
        abstract function obtener($id);
    }
?>