<?php
    abstract class AbstractControlador{   

        protected $modelo;    
        
        abstract function ejecuta();

    }
?>